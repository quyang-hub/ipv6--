package com.bingo.qa.service;

/**
 */

public interface SensitiveService {
    /**
     * 过滤文本
     * @param text
     * @return
     */
    String filter(String text);
}
