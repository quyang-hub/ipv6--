package com.bingo.qa.util;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

/**
 */

public class RequestUtil {

    private static Logger LOGGER = LoggerFactory.getLogger(RequestUtil.class);

    public static Document getDocument(String url, Map<String, String> header) {

        try {
            return Jsoup.connect(url).headers(header).get();
        } catch (IOException e) {
            LOGGER.error("URL 解析失败", e.getMessage());
            return null;
        }
    }

    public static String getUrl(String type, int pageNum) {
        return String.format("https://www.v2ex.com/go/%s?p=%s", type, pageNum);
    }

}
